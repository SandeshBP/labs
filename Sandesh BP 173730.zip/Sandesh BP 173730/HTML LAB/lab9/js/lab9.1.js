function storeval(usr){
    var uname=usr.uname.value;
    var psw=usr.psw.value;
    var eml=usr.mail.value;
    var adrs=usr.adrs.value;
    var cty=usr.cty.value;
    localStorage.setItem("uname",uname);
    localStorage.setItem("psw",psw);
    localStorage.setItem("eml",eml);
     localStorage.setItem("adrs",adrs);
    localStorage.setItem("cty",cty);

    sessionStorage.setItem("uname",uname);
    sessionStorage.setItem("psw",psw);
    sessionStorage.setItem("eml",eml);
    sessionStorage.setItem("adrs",adrs);
    sessionStorage.setItem("cty",cty);
  window.open("new.html");
}
function load(){
    alert("11");
    var a=sessionStorage.getItem("uname");
    alert(a);
    var b=sessionStorage.getItem("eml");
    var c=sessionStorage.getItem("adrs");
    var d=sessionStorage.getItem("cty");
    document.getElementById("nm")
    .innerHTML="welcome "+a;
    document.getElementById("eml")
    .innerHTML="email is: "+b;
    document.getElementById("ads")
    .innerHTML="address is: "+c;
    document.getElementById("cty")
    .innerHTML="city is: "+d;
    
    


}
