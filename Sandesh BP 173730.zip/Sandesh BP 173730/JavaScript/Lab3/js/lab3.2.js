function search(string,char){
    var str=(string.value).toUpperCase();
    var ch =(char.value).toUpperCase();
var index=-1       

for(let i of str){
    index ++;
    if(ch===i){
       break;
}
}     

   
   if(index!=-1){
          document.write("Original String: "+str)
          document.write("<br/>Search String: "+ch)
          document.write("<br/>Element found at "+index)

   }
    else
    document.write("Not Found")
}