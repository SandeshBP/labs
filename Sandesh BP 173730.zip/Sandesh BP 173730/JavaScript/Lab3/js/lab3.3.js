function search(string,char){
    alert("1")
    var str=string.value;
    var ch =char.value;

   var index= str.match(/ch/)
   if(index)
    var display=`
Original Strin -${str}
Search String -${ch}
Search element found at -${index}`
    else
     display="Not Found"
   document.write(display)
}