
var dateObj=new Date();
var dayArray=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"]
var monthArray=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
var day= dateObj.getDay();
var month= dateObj.getMonth();
var date= dateObj.getDate();
var year=dateObj.getFullYear();
var wish;

var hour=dateObj.getHours()
var min=dateObj.getMinutes()
var sec=dateObj.getSeconds()
if(hour<12)
    wish="Good Morning"
else if (hour>12 && hour<17)
    wish="Good Afternoon"
else
    wish="Good Evening"

var dateString=dayArray[day] +" "+monthArray[month]+" "+date+" "+hour+":"+min+":"+sec+" "+" "+year;

document.getElementById("date").innerHTML=dateString;
document.getElementById("wish").innerHTML=wish;
