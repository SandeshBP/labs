var n=100;
var count=0;
for(var i=0; i<n; i++)
{  
    count++;
    document.write( i+" ");
        
    if(count==10)
    {
        document.write("</br>");
        count=0;
    }
}