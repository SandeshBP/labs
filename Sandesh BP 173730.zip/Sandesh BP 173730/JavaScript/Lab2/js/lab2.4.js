
    document.write("------------------------------------------------------------</br>");
    document.write("********** Calculate Compound Interest**********<br/>");
    document.write("------------------------------------------------------------</br>");
    var pa=1000,rt=10 ,n=1;
    var compoundInterest;
    compoundInterest= (pa*Math.pow(1+(rt/100),n))-pa;
    document.write("Principal- "+pa+" "+"rs"+"</br>");
    document.write("Rate of Interest- "+rt+" "+"%"+"</br>");
    document.write("Period- "+n+" "+"yr"+"</br>");
    document.write("comp Interest- "+ compoundInterest +"</br>");