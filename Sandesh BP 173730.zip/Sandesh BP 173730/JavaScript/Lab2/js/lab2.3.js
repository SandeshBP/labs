var n=100;
                   var count=0, i=0;
                   do
                   {  
                       count++;
                       document.write(i+" ");
                       i++;
                       if(count==10)
                       {
                           document.write("</br>");
                           count=0;
                       }
                   }while(i<n)